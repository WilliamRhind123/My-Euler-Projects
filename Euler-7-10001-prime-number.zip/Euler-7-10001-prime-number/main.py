a = 0
Prime = False
Prime_List = []

def is_prime(n):
  global Prime
  Prime = True 
  for i in range(2,n):
    if (n%i) == 0:
      Prime = False
      break
    else: 
      Prime = True

i = 1

while True:
  i+=1
  is_prime(i)
  if Prime == True:
    a+=1
    #print(i)
  if a == 690: #change to find that number prime.
    break

print(f'the {a}th prime number is {i}')