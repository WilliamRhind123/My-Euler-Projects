list = []
sSum = []

lenght = 1
a = 1
b = 1
index = 2

while lenght < 10: #1000


  a = a + b
  index += 1
  b = a + b
  index += 1

  sSum.clear()
  list.clear()

  list.append(a)

  result = 1
  for terms in list:
    result = result * terms
  #print(result)

  convertedresult = str(result)

  for i in (convertedresult):
    sSum.append(int(i))
    lenght = len(sSum)
  #print(len(sSum))

  #if len(sSum) > 10:
    #print(f" a = {a} has a lenght of {lenght} greater then 10")

  #else:
    #print(f"a = {a} has a lenght of {lenght} less then 10")

  sSum.clear()
  list.clear()

  list.append(b)

  result = 1
  for terms in list:
    result = result * terms
  #print(result)

  convertedresult = str(result)

  for i in (convertedresult):
    sSum.append(int(i))
    lenght = len(sSum)
  #print(len(sSum))

  #if len(sSum) > 10:
    #print(f"b = {b} has a lenght of {lenght} less then 10")

  #else:
    #print(f"b = {b} has a lenght of {lenght} less then 10")


print(f"the first number with {lenght} digits is a = {a}")
print(index-1)
#print(f"the first number with {lenght} digits is  b = {b}")
#print(index)