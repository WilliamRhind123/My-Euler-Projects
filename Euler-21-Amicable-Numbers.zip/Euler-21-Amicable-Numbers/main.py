Factorise_List = []
Amicable_Numbers_List = []

def Factorise(Input):
  Factorise_List.clear()
  for i in range(1, Input):
    if Input % i == 0:
      Factorise_List.append(i)


i = 1

while i < 1001:

  Factorise(i)

  a = (sum(Factorise_List))

  #print(f'{a} is the sum of the factors of {i}')

  Factorise(a)

  b = sum(Factorise_List)

  #print(f'{b} is the sum of the factors of {a}')

  if b == i:
    if b not in Amicable_Numbers_List:
      Amicable_Numbers_List.append(b)
    if a not in Amicable_Numbers_List:
      Amicable_Numbers_List.append(a)
  i+=1



print(Amicable_Numbers_List)

print(sum(Amicable_Numbers_List))