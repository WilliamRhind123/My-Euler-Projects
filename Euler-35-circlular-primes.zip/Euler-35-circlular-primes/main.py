BrockenUpNumber = []
TermsList = []
ListOfCompleteNumbers = []
AnotherList = []
CircularPrime = []


def is_prime(n):
  #global Prime
  #Prime = True 
  for i in range(2,n):
    if (n%i) == 0:
      return False
      break
    else: 
      return True





a = int(input("Enter a number: "))

a = str(a)


BrockenUpNumber.clear()
TermsList.clear()
ListOfCompleteNumbers.clear()


for term in a:
  #print(term)
  TermsList.append(term)
  BrockenUpNumber.append(term)

#print(len(TermsList))

for i in range(len(TermsList)):

  print(BrockenUpNumber)

  b = ("".join(BrockenUpNumber))
  #print(b)
  b = int(b)
  print(b)
  AnotherList.append(b)

  #is_prime(b)

  #if Prime == False:
    #print(f'{b} is not prime')
    #break
  #if Prime == True:
    #print(f'{b} is prime')
    #Circularprime.append(b)


  BrockenUpNumber = BrockenUpNumber[1:] + [BrockenUpNumber[0]]
  print(AnotherList)


for term in AnotherList: 
  
  print(len(AnotherList))
  
  x = (len(AnotherList))

  if x == 1: 
    if is_prime(AnotherList[x - x]) == True:
      if AnotherList[x - x] not in CircularPrime:
         CircularPrime.append(AnotherList[x - x])
  elif x == 2:
    if is_prime(AnotherList[x - x]) == True and is_prime (AnotherList[x-x+1]) == True:
      if AnotherList[x - x] not in CircularPrime:
       CircularPrime.append(AnotherList[x - x])
  elif x == 3: 
    if is_prime(AnotherList[x - x]) == True and is_prime(AnotherList[x-x+1]) == True and is_prime(AnotherList[x-x+2]) == True:
      if AnotherList[x - x] not in CircularPrime:
       CircularPrime.append(AnotherList[x - x])
  


if(len(CircularPrime)) == 0:
  print("Not a Circular prime")

else: 
  print(f'{CircularPrime} is a circular prime')




