list = []
fifth_digit_power = []

a = 2

while a <1000000:
  a = str(a)

  for i in a:
    list.append(int(i)**5)

  #print(list)
  #print(sum(list))

  if sum(list) == int(a):
    print(f"{a} is a digit fifth number")
    fifth_digit_power.append(int(a))

  list.clear()
  a = int(a)
  a+=1

print(fifth_digit_power)

#out of 1 million numbers there are only 6 fifth digit number those being: 
# 4150, 4151, 54748, 92727, 93084, 194979
# the sum being 443839

print(sum(fifth_digit_power))
