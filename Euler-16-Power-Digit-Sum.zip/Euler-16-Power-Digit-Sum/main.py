List = []

a = 2**1000

for digit in str(a):
  List.append(int(digit))
print(sum(List))




