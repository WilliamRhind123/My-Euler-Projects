a = 2
b = 2
list = []

while b < 101:
  while a < 101:
    #print(f'{a**b}')
    if (a**b) not in list:
      list.append(a**b)
    a+=1

  b+=1
  a = 2

#print(list)
print(len(list))
 
