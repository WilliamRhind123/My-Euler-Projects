Prime = True 
Factorise_List = []
PrimeFactors = []

def is_prime(n):
  global Prime
  Prime = True 
  for i in range(2,n):
    if (n%i) == 0:
      Prime = False
      break
    else: 
      Prime = True
      
  #if Prime:
    #print(f"{n} is Prime")
  #elif not Prime:  
    #print(f"{n} is not Prime")

def Factorise(Input):
  Factorise_List.clear()
  for i in range(1, Input + 1):
    if Input % i == 0:
      Factorise_List.append(i)
  #print(Factorise_List)

Number = 13195
Factorise(Number)

for terms in (Factorise_List):
  Prime = True
  is_prime(terms)
  #print(f'prime is {Prime}')
  if Prime:
    PrimeFactors.append(terms)
 
#print(PrimeFactors)
print(f'the Largest prime facter of {Number} is  {max(PrimeFactors)}')





      

