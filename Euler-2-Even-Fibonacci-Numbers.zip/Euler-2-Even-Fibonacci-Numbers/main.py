Numbers = []

a = 1
b = 1

while b < 4000000:
  a = a + b
  b = a + b

  if (a/2).is_integer():
    #print(f"a = {a}")
    Numbers.append(a)
    
  elif (b/2).is_integer():
    #print(f"b = {b}")
    Numbers.append(b)

print(f"sum of numbers {sum(Numbers)}")