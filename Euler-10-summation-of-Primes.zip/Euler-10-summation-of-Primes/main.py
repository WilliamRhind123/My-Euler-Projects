Prime = False
Prime_List = []

def is_prime(n):
  global Prime
  Prime = True 
  for i in range(2,n):
    if (n%i) == 0:
      Prime = False
      break
    else: 
      Prime = True



i = 20
a = i

while i >0:
  is_prime(i)
  if Prime == True and i != 1:
    Prime_List.append(i)
  i-=1


print(f'the sum of all the prime numbers under {a} is {sum(Prime_List)}')

