Numbers = []
Loop = 1

while Loop < 1000:
  
  Loop1 = Loop/3
  Loop2 = Loop/5
  
  if (Loop1).is_integer():
    #print(Loop)
    Numbers.append(Loop)

  elif (Loop2).is_integer():
    #print(Loop)
    Numbers.append(Loop)

  Loop +=1
  
  

#print(Numbers)

print(f" the total is {sum(Numbers)}")