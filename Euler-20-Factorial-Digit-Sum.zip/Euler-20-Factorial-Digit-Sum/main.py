n  = 100 #100
list = []
sSum = []

while n > 0:
  list.append(n)
  n-=1

result = 1
for terms in list:
  result = result * terms
#print(result)

convertedresult = str(result)

for i in (convertedresult):
  sSum.append(int(i))
print(sum(sSum))

