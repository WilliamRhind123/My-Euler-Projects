CollatzChain = []
Chainlengths = []
StartingNums = []
Chainlengthslengths = []


def CollatzNum(Input):
  StartingNum = Input
  CollatzChain.clear()
  CollatzChain.append(Input)

  while Input != 1:
    if Input % 2 == 0:
      Input = Input / 2
      #print(Input)
      CollatzChain.append(Input)
    else:
      Input = (Input * 3) + 1
      #print(Input)
      CollatzChain.append(Input)

  #print(CollatzChain)
  print(f"Starting Number = {StartingNum}", end=" ")
  print(f"Chain Length = {len(CollatzChain)}")
  StartingNums.append(StartingNum)
  Chainlengths.append(len(CollatzChain))
  #Chainlengthslengths.append(Chainlengths)


i = 1
while i < 20:
  CollatzNum(i)
  print(Chainlengths)
  i += 1
  print(StartingNums)
  a = (max(Chainlengths))
  b = (Chainlengths.index(a) + 1)
print(f"{b} has the longest Collatz Chain")
