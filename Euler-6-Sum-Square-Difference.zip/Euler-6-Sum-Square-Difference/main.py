list_of_numbers = []
squared_numbers = []
sum_of_squared_numbers = 0

i = 1

for i in range(1, 100 + 1):
  list_of_numbers.append(i)
  i += 1
for terms in list_of_numbers:
  squared_numbers.append(terms**2)
#print(squared_numbers)
#print("sum of squared numbers is:")
#print(sum(squared_numbers))
sum_of_squared_numbers = sum(squared_numbers)

square_of_sum = []
total_1through100 = 0
total_1through100squared = 0

for a in range(1, 100 + 1):
  square_of_sum.append(a)
  a += 1
#print(sum(square_of_sum))
total_1through100 = sum(square_of_sum)
total_1through100squared = total_1through100**2

#print(f"{total_1through100squared} - {sum_of_squared_numbers} =")
abc = (total_1through100squared - sum_of_squared_numbers)

print(f"The answer is {abc}")
