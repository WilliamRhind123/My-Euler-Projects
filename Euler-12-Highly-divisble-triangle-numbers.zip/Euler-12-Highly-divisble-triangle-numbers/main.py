FactoriseList = []

def Factorise(Input):

  for i in range(1, Input + 1):
    if Input % i == 0:
      FactoriseList.append(i)
  print(FactoriseList)

List = [1,] 

while True: 
  FactoriseList.clear()
  List.append(max(List)+1)
  print(sum(List))
  Factorise(sum(List))
  print(f"length = {len(FactoriseList)}")

  if len(FactoriseList) >= 20:
    break
