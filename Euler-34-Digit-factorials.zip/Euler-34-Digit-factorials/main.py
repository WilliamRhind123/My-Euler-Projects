def Factorial(input): 
  global a
  a = 1
  list = []
  while input > 1 : 
    list.append(input)
    input = input - 1
  #print(list)
  for x in list:
    a = a*x
  print(a)
  list.clear()

#Factorial(7)

List = []
Factorials = []


b = int(input(": "))

b = str(b)

for i in b:
 List.append(int(i))

for j in List:
  Factorial(j)
  Factorials.append(a)
  
print(Factorials)

if sum(Factorials) == int(b):
  print("This is a strong number")