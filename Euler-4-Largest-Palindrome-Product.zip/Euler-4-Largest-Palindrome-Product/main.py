num = 2000002
Palindrome_list = []


a = 999
b = 999

while a > 100:
  num = a*b
  reverse = int(str(num)[::-1])

  print(f"{a} * {b} = {num}")

  if num == reverse:
    print(f'{num} is a Palindrome')
    Palindrome_list.append(num)
  
  a -=1
  if a == 100:
    a = 999
    b -=1

  
  if b < 980:
    break
  #I have to use this loop as the website does not allow me to use the full power of the computer and brute forcing it like this takes ages if i dont cut it off early. I need to find a solution to this. 


print(Palindrome_list)
Largest_palindrome_product = (max(Palindrome_list))
print(f"largest palindrome product = {Largest_palindrome_product}")