List = [ "MARY","PATRICIA","LINDA","BARBARA","ELIZABETH","JENNIFER","MARIA","SUSAN","MARGARET","DOROTHY","LISA","NANCY","KAREN","BETTY","HELEN","SANDRA","DONNA","CAROL","RUTH","SHARON","MICHELLE","LAURA","SARAH","KIMBERLY","DEBORAH","JESSICA","SHIRLEY","CYNTHIA","ANGELA","MELISSA" ]

#print(List)
SortedList = sorted(List)
#print(SortedList)
Score = 0
Scores = []

for term in SortedList:
  print(term)
  for letter in term:
    print(letter)
    if letter == "A":
        Score+=1
    elif letter == "B":
        Score+=2
    elif letter == "C":
        Score+=3
    elif letter == "D":
        Score+=4
    elif letter == "E":
        Score+=5
    elif letter == "F":
        Score+=6
    elif letter == "G":
        Score+=7
    elif letter == "H":
        Score+=8
    elif letter == "I":
        Score+=9
    elif letter == "J":
        Score+=10
    elif letter == "K":
         Score+=11
    elif letter == "L":
         Score+=12
    elif letter == "M":
         Score+=13
    elif letter == "N":
         Score+=14
    elif letter == "N":
         Score+=15
    elif letter == "P":
         Score+=16
    elif letter == "Q":
         Score+=17
    elif letter == "R":
         Score+=18
    elif letter == "S":
         Score+=19
    elif letter == "T":
          Score+=20
    elif letter == "U":
         Score+=21
    elif letter == "V":
         Score+=22
    elif letter == "W":
         Score+=23
    elif letter == "X":
         Score+=24
    elif letter == "Y":
         Score+=25
    elif letter == "Z":
         Score+=26
  print(Score)
  print(SortedList.index(term))
  Score = Score * SortedList.index(term)
  print(Score)
  Scores.append(Score)
  Score=0

print(f"total score of list {sum(Scores)}")

