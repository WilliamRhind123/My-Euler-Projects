i = 1
list = []
list2 = []

while i < 1001:
  list.append(i**i)
  i+=1

#print(list) 
a = (sum(list))
a = str(a)
#print(a)
b = len(a)


for i in str(a):
  list2.append(i)

print(list2[b - 10] + list2[b - 9] + list2[b - 8] + list2[b - 7] + list2[b - 6] + list2[b - 5] + list2[b - 4] + list2[b - 3] + list2[b - 2] + list2[b - 1])



#9110846700